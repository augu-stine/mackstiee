<?php
// Include the database configuration file
include 'include/config.php';

// Check if empid parameter is set and is not empty
if (isset($_GET['empid']) && !empty($_GET['empid'])) {
    // Get the empid parameter value
    $empid = $_GET['empid'];

    // Prepare the SQL query to delete the employee with the specified empid
    $sql = "DELETE FROM tblemployee WHERE id = :empid";
    $query = $dbh->prepare($sql);

    // Bind the empid parameter value
    $query->bindParam(':empid', $empid, PDO::PARAM_INT);

    // Execute the query
    if ($query->execute()) {
        // Employee deleted successfully, redirect back to the employee management page
        header('Location: employee-management.php');
        exit;
    } else {
        // Error occurred while deleting employee
        echo "Error: Unable to delete employee.";
    }
} else {
    // Redirect back to the employee management page if empid parameter is not provided
    header('Location: employee-management.php');
    exit;
}
?>
-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 14, 2024 at 04:05 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `empmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladdsalary`
--

CREATE TABLE `tbladdsalary` (
  `id` int(11) NOT NULL,
  `Department` varchar(45) DEFAULT NULL,
  `empid` varchar(45) DEFAULT NULL,
  `salary` varchar(45) DEFAULT NULL,
  `allowancesalary` varchar(45) DEFAULT NULL,
  `total` varchar(45) DEFAULT NULL,
  `create_date` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbladdsalary`
--

INSERT INTO `tbladdsalary` (`id`, `Department`, `empid`, `salary`, `allowancesalary`, `total`, `create_date`) VALUES
(4, '9', '16082000', '50000', '2000', '52000', '2023-10-20 14:46:22'),
(5, '9', '30082001', '25000', '0', '25000', '2023-10-20 15:15:42'),
(6, '9', '18091999', '27000', '0', '27000', '2023-10-22 06:36:13'),
(7, '9', '123456789', '22000', '0', '22000', '2024-01-10 15:02:09'),
(8, '12', '08062000', '35000', '2000', '37000', '2024-01-10 15:02:27'),
(9, '9', '16082000', '50000', '', '50000', '2024-01-10 15:09:23'),
(10, '13', '18091999', '30000', '1000', '31000', '2024-01-10 15:14:56'),
(11, '11', '30082001', '32000', '0', '32000', '2024-01-10 15:15:34'),
(12, '14', '30061999', '20000', '0', '20000', '2024-03-11 03:58:03'),
(13, '11', '30071997', '35000', '0', '35000', '2024-03-11 03:58:17'),
(14, '14', '30061999', '25000', '0', '25000', '2024-03-11 03:59:41'),
(15, '12', '18042001', '30000', '1000', '31000', '2024-03-11 03:59:58'),
(16, '14', '18091999', '27000', '900', '27900', '2024-03-11 04:00:15'),
(17, '9', '123456789', '26000', '0', '26000', '2024-03-11 04:00:32'),
(18, '11', '30071997', '35000', '600', '35600', '2024-03-11 04:00:51'),
(19, '12', '18042001', '30000', '0', '30000', '2024-03-11 04:01:34'),
(20, '12', '08062000', '35000', '', '35000', '2024-03-11 04:03:15'),
(21, '23', '369', '1000', '0', '1000', '2024-03-12 04:44:14');

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `create_date` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`id`, `name`, `email`, `mobile`, `password`, `create_date`) VALUES
(1, 'HR', 'admin@gmail.com', '9388736393', 'e6e061838856bf47e1de730719fb2609', '2022-11-19 11:25:17');

-- --------------------------------------------------------

--
-- Table structure for table `tbldepartment`
--

CREATE TABLE `tbldepartment` (
  `id` int(11) NOT NULL,
  `DepartmentName` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbldepartment`
--

INSERT INTO `tbldepartment` (`id`, `DepartmentName`) VALUES
(6, 'Admin'),
(9, 'IT'),
(11, 'Marketing'),
(12, 'Legal '),
(14, 'Quality Assurance'),
(23, 'd1');

-- --------------------------------------------------------

--
-- Table structure for table `tblemployee`
--

CREATE TABLE `tblemployee` (
  `id` int(11) NOT NULL,
  `EmpId` varchar(45) DEFAULT NULL,
  `fname` varchar(45) DEFAULT NULL,
  `lname` varchar(45) DEFAULT NULL,
  `department_name` varchar(100) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `photo` varchar(200) DEFAULT NULL,
  `dob` varchar(45) DEFAULT NULL,
  `date_of_joining` varchar(45) DEFAULT NULL,
  `password` varchar(450) DEFAULT NULL,
  `create_date` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblemployee`
--

INSERT INTO `tblemployee` (`id`, `EmpId`, `fname`, `lname`, `department_name`, `email`, `mobile`, `country`, `state`, `city`, `address`, `photo`, `dob`, `date_of_joining`, `password`, `create_date`) VALUES
(2, '30082001', 'Aswin', 'Willy', '11', 'aswin@gmail.com', '7902855951', 'India', 'Kerala', 'kakkanad', 'Vithaythil(h) ,kakkand P.O', '', '', '2023-08-30', 'bf4460f4ef9aa942d9d4d2e4a9264291', '2023-10-20 15:11:58'),
(3, '16082000', 'Augustine', 'Mathew', '9', 'augu414@gmail.com', '8590412672', 'India', 'Kerala', 'Aluva', 'Painadath (h), Neericode P.O', '../uploads/1710207694-1668704792-user (4).png', '2000-08-16', '2023-08-16', 'bdd7f5483457f996a76be6df8deca6c3', '2022-11-22 01:51:29'),
(4, '18091999', 'Jenson', 'Aj', '14', 'jenson@gmail.com', '9349983241', 'India', 'Kerala', 'Aluva', 'ABC street Aluva', '', '1999-09-18', '2023-06-02', '0a2851c615809f003c3c208179a8a97b', '2023-10-22 06:28:14'),
(5, '123456789', 'Likhil', 'Jacaob', '9', 'lihkil@gmail.com', '9387912345', 'India', 'Kerala', 'Angamaly', 'ABC street  angamaly', '../uploads/1704898228-20230806_132114.jpg', '2000-06-30', '2023-11-16', '0058c43805b3b4bbe9218fba4b5a6f2f', '2024-01-10 14:50:28'),
(6, '08062000', 'Alfin', 'Paul', '12', 'alfin@gmail.com', '6238509012', 'India', 'Kerala', 'Aluva', 'Mundempilly H\r\nAlanagd P.O', '../uploads/1704898636-20230602_003248.jpg', '2000-06-08', '2023-12-04', 'e0c738d18d8060ca2a7cc78c4d8aa07e', '2024-01-10 14:57:16'),
(7, '30071997', 'Meera ', 'Mathew', '11', 'meeramathew@gmail.com', '9526721550', 'India', 'Kerala', 'Trissur', 'paiandath(h) neericode p.o \r\n', '../uploads/1710128945-20230602_003248.jpg', '1997-07-30', '2023-12-13', 'ac55bd35969afcd56724d07283afd34e', '2024-03-11 03:49:05'),
(9, '30061999', 'Ajay', 'joby', '14', 'ajay@gmail.com', '9875642312', 'India', 'Kerala', 'Aluva', 'manavalan p.o', '../uploads/1710129400-1668704792-user (4).png', '1999-06-30', '2024-01-23', '978d748c39826b4a2df9767b910f887b', '2024-03-11 03:56:40'),
(10, '369', 'e1', 'e2', '23', 'e1@gmail.com', '1234567891', 'india', 'tamilnadu', 'city1', 'abc street', '../uploads/1710218625-1668704792-user (4).png', '2023-09-06', '2024-03-06', 'caf1a3dfb505ffed0d024130f58c5cfa', '2024-03-12 04:43:45');

-- --------------------------------------------------------

--
-- Table structure for table `tblleave`
--

CREATE TABLE `tblleave` (
  `id` int(11) NOT NULL,
  `userID` varchar(45) DEFAULT NULL,
  `EmpID` varchar(45) DEFAULT NULL,
  `LeaveType` varchar(45) DEFAULT NULL,
  `FromDate` varchar(45) DEFAULT NULL,
  `Todate` varchar(45) DEFAULT NULL,
  `Description` varchar(450) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `adminremarks` varchar(450) DEFAULT NULL,
  `Create_date` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblleave`
--

INSERT INTO `tblleave` (`id`, `userID`, `EmpID`, `LeaveType`, `FromDate`, `Todate`, `Description`, `status`, `adminremarks`, `Create_date`) VALUES
(2, '16082000', '16082000', 'Casual Leaves- CL', '20-08-2023', '22-08-2000', 'Casual Leaves', 'accepted', NULL, '2023-10-20 15:14:24'),
(7, '3', '16082000', '1', '2023-10-20', '2023-10-23', 'i have hospital case ', 'Approved', 'accpted', '2023-10-20 15:21:39'),
(8, '4', '18091999', '1', '2023-11-03', '2023-11-10', 'i need to take 6 days of leave ,kindly allow the leave', 'Approved', '', '2023-10-22 06:31:32'),
(9, '3', '16082000', '1', '2023-10-22', '2023-10-23', 'cassual lave', 'Reject', 'there is no exact reason', '2023-10-22 07:36:58'),
(10, '5', '123456789', '6', '2024-01-02', '2024-01-03', 'Fever', 'Approved', '', '2024-01-10 15:46:59'),
(11, '6', '08062000', '2', '2024-12-28', '2024-01-02', '', 'Reject', '', '2024-01-10 16:09:14'),
(12, '9', '30061999', '6', '2024-02-05', '2024-02-07', 'sick leave', 'Approved', '', '2024-03-11 04:56:26'),
(13, '3', '16082000', 'NA', '', '', '', 'Pending', NULL, '2024-03-12 01:39:28'),
(14, '10', '369', '9', '2024-03-12', '2024-03-13', 'fever', 'Approved', '', '2024-03-12 04:47:55');

-- --------------------------------------------------------

--
-- Table structure for table `tblleavetype`
--

CREATE TABLE `tblleavetype` (
  `id` int(11) NOT NULL,
  `leaveType` varchar(45) DEFAULT NULL,
  `create_date` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblleavetype`
--

INSERT INTO `tblleavetype` (`id`, `leaveType`, `create_date`) VALUES
(1, 'Casual Leaves- CL', '2022-03-30 14:13:40'),
(2, 'Earned Leave-EL', '2022-11-17 16:38:37'),
(4, 'Maternity Leave - ML', '2024-01-10 14:59:57'),
(5, 'Bereavement Leave - BL', '2024-01-10 15:00:27'),
(6, 'Sick Leave - SL', '2024-01-10 15:00:51'),
(9, 'l1', '2024-03-12 04:38:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladdsalary`
--
ALTER TABLE `tbladdsalary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbldepartment`
--
ALTER TABLE `tbldepartment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblemployee`
--
ALTER TABLE `tblemployee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblleave`
--
ALTER TABLE `tblleave`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblleavetype`
--
ALTER TABLE `tblleavetype`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladdsalary`
--
ALTER TABLE `tbladdsalary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbldepartment`
--
ALTER TABLE `tbldepartment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tblemployee`
--
ALTER TABLE `tblemployee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tblleave`
--
ALTER TABLE `tblleave`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tblleavetype`
--
ALTER TABLE `tblleavetype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
